import Image from 'next/image'
import logo from '../../assets/SponsorLogos/logo.png';


export default function Sponsors() {
  return (
    <div>
    <div className="container mx-auto mt-8 flex justify-center items-center ">
     <div><h1 className="text-4xl font-bold justify-center items-center">Abhisarga'24 <br/> sponsers</h1> </div> 
      <div className="bg-white p-8 mt-4 rounded-md m-12 flex justify-end ml-40">
        <div className="card p-10">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26"/>
          <h2 className="text-2xl font-bold mb-4">Sponsors</h2>
        </div>
      </div>
    </div>

    <div id="logoContainer" className=" max-w-7xl mx-auto overflow-hidden mt-8 bg-white p-11 rounded-lg ">
  <div className="max-w-2xl mx-auto"> {/* Center content within a maximum width */}
    <div className="flex space-x-4 animate-scroll">
      <div className="logo flex-shrink-0 w-full flex items-center justify-start space-x-8">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
      </div>
    </div>
    <h1 className="text-2xl font-bold mt-4 mb-2 text-center">Diamond sponsor</h1>
  </div>
</div>

<div id="logoContainer" className=" max-w-7xl mx-auto overflow-hidden mt-10 bg-white p-11 rounded-lg ">
  <div className="max-w-2xl mx-auto"> {/* Center content within a maximum width */}
    <div className="flex space-x-4 animate-scroll">
      <div className="logo flex-shrink-0 w-full flex items-center justify-start space-x-8">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
      </div>
    </div>
    <h1 className="text-2xl font-bold mt-4 mb-2 text-center">Platinum sponsors</h1>
  </div>
</div>


<div id="logoContainer" className=" max-w-7xl mx-auto overflow-hidden mt-10 bg-white p-11 rounded-lg ">
  <div className="max-w-2xl mx-auto"> {/* Center content within a maximum width */}
    <div className="flex space-x-4 animate-scroll">
      <div className="logo flex-shrink-0 w-full flex items-center justify-start space-x-8">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
      </div>
    </div>
    <h1 className="text-2xl font-bold mt-4 mb-2 text-center ">Gold Sponsor</h1>
  </div>
</div>

<div id="logoContainer" className=" max-w-7xl mx-auto overflow-hidden mt-10 bg-white p-11 rounded-lg ">
  <div className="max-w-2xl mx-auto"> {/* Center content within a maximum width */}
    <div className="flex space-x-4 animate-scroll">
      <div className="logo flex-shrink-0 w-full flex items-center justify-start space-x-8">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
      </div>
    </div>
    <h1 className="text-2xl font-bold mt-4 mb-2 text-center ">Silver sponsor</h1>
  </div>
</div>

<div id="logoContainer" className=" max-w-7xl mx-auto overflow-hidden mt-10 bg-white p-11 rounded-lg ">
  <div className="max-w-2xl mx-auto"> {/* Center content within a maximum width */}
    <div className="flex space-x-4 animate-scroll">
      <div className="logo flex-shrink-0 w-full flex items-center justify-start space-x-8">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
      </div>
    </div>
    <h1 className="text-2xl font-bold mt-4 mb-2 text-center ">Food & Beverages partner</h1>
  </div>
</div>

<div id="logoContainer" className=" max-w-7xl mx-auto overflow-hidden mt-10 bg-white p-11 rounded-lg ">
  <div className="max-w-2xl mx-auto"> {/* Center content within a maximum width */}
    <div className="flex space-x-4 animate-scroll">
      <div className="logo flex-shrink-0 w-full flex items-center justify-start space-x-8">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
      </div>
    </div>
    <h1 className="text-2xl font-bold mt-4 mb-2 text-center ">Banking Partner</h1>
  </div>
</div>

<div id="logoContainer" className=" max-w-7xl mx-auto overflow-hidden mt-10 bg-white p-11 rounded-lg ">
  <div className="max-w-2xl mx-auto"> {/* Center content within a maximum width */}
    <div className="flex space-x-4 animate-scroll">
      <div className="logo flex-shrink-0 w-full flex items-center justify-start space-x-8">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
      </div>
    </div>
    <h1 className="text-2xl font-bold mt-4 mb-2 text-center ">Travel Partner</h1>
  </div>
</div>

<div id="logoContainer" className=" max-w-7xl mx-auto overflow-hidden mt-10 bg-white p-11 rounded-lg ">
  <div className="max-w-2xl mx-auto"> {/* Center content within a maximum width */}
    <div className="flex space-x-4 animate-scroll">
      <div className="logo flex-shrink-0 w-full flex items-center justify-start space-x-8">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
      </div>
    </div>
    <h1 className="text-2xl font-bold mt-4 mb-2 text-center ">Delivery Partner</h1>
  </div>
</div>

<div id="logoContainer" className=" max-w-7xl mx-auto overflow-hidden mt-10 bg-white p-11 rounded-lg ">
  <div className="max-w-2xl mx-auto"> {/* Center content within a maximum width */}
    <div className="flex space-x-4 animate-scroll">
      <div className="logo flex-shrink-0 w-full flex items-center justify-start space-x-8">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
      </div>
    </div>
    <h1 className="text-2xl font-bold mt-4 mb-2 text-center ">Educational Partner</h1>
  </div>
</div>

<div id="logoContainer" className=" max-w-7xl mx-auto overflow-hidden mt-10 bg-white p-11 rounded-lg ">
  <div className="max-w-2xl mx-auto"> {/* Center content within a maximum width */}
    <div className="flex space-x-4 animate-scroll">
      <div className="logo flex-shrink-0 w-full flex items-center justify-start space-x-8">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
      </div>
    </div>
    <h1 className="text-2xl font-bold mt-4 mb-2 text-center ">Credential partner</h1>
  </div>
</div>

<div id="logoContainer" className=" max-w-7xl mx-auto overflow-hidden mt-10 bg-white p-11 rounded-lg ">
  <div className="max-w-2xl mx-auto"> {/* Center content within a maximum width */}
    <div className="flex space-x-4 animate-scroll">
      <div className="logo flex-shrink-0 w-full flex items-center justify-start space-x-8">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
      </div>
    </div>
    <h1 className="text-2xl font-bold mt-4 mb-2 text-center ">Crypto Partner</h1>
  </div>
</div>

<div id="logoContainer" className=" max-w-7xl mx-auto overflow-hidden mt-10 bg-white p-11 rounded-lg ">
  <div className="max-w-2xl mx-auto"> {/* Center content within a maximum width */}
    <div className="flex space-x-4 animate-scroll">
      <div className="logo flex-shrink-0 w-full flex items-center justify-start space-x-8">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
      </div>
    </div>
    <h1 className="text-2xl font-bold mt-4 mb-2 text-center ">Media & Digital Partner</h1>
  </div>
</div>


<div id="logoContainer" className=" max-w-7xl mx-auto overflow-hidden mt-10 bg-white p-11 rounded-lg ">
  <div className="max-w-2xl mx-auto"> {/* Center content within a maximum width */}
    <div className="flex space-x-4 animate-scroll">
      <div className="logo flex-shrink-0 w-full flex items-center justify-start space-x-8">
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
        <Image src={logo} width={100} height={100} alt="Company Logo" className="w-auto h-26" />
      </div>
    </div>
    <h1 className="text-2xl font-bold mt-4 mb-2 text-center ">Event Partner</h1>
  </div>
</div>

    </div>
  )
}
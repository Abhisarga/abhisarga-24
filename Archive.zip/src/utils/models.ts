enum Models {
    user = "user",
    club = "club",
    event = "event",
    session = "session",
    theme = "theme",
    sponsor = "sponsor"
}

export default Models